************************************************************************************************************************
*******************************************     SVS SD Card Config File     ********************************************
*******************************************    SCALABLE SWITCH LLC 2024     ********************************************
************************************************************************************************************************

Description
-----------

Starting with firmware version 1.14 STABLE, the SVS control module can now load a configuration file that contains user 
definable settings for various functions of the SVS.

Usage Instructions
------------------

Place the file labeled "cfg.txt" into the root of a fat32 formatted micro SD card. Insert the SD card into your SVS and
plug in the power. The SVS will load the settings from the config file and keep those settings saved for the duration
of that power cycle. If you wish to change settings in the config file simply unplug your SVS, insert the SD card into
your computer and edit the "cfg.txt" file in whatever way you need. The updated config settings will be loaded the next
time you power your SVS on with the SD card inserted.

Settings Descriptions (as of FW 1.14)
-------------------------------------

1. "Pushbutton Mode =": This setting determines which mode the control module pushbutton should operate in. The possible
options are "cycle" and "seek". Cycle mode is the default behavior, and it allows you to cycle through each input one
by one. Seek is a new feature in FW 1.14 that allows you to seek for the next active input, skipping inactive inputs.

2. "attractmode delay(milliseconds) =": This sets the time interval between input cycles in attract mode. You can use
this setting to adjust how long each input stays selected before cycling to the next one. Time is calculated in
milliseconds, so however many seconds you want just multiply that amount by 1000.

3. "Serial Baudrate =": This will tell the future RS232 module what speed to send out serial commands. Without the RS232
module this setting doesn't perform any function.
