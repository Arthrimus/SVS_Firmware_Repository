************************************************************************************************************************
******************************************* SVS RT5X IR Code SD Card Preset ********************************************
*******************************************    SCALABLE SWITCH LLC 2024     ********************************************
************************************************************************************************************************

Description
-----------
This is a set of premade IR code files for the Retro Tink 5x Pro. Each folder contains a text file with the IR code for 
one of the profile slots of the RT5X. There are a total of 10 profile slots on the RT5X so each input folder contains
the code for the profile slot of the same number. You can reorganize the IR codes depending on your needs, simply rename
the folder to match the input number that matches the input on the SVS that you want to bind the IR code to.

Usage Instructions
------------------
Format your micro SD card as FAT32 then unzip the contents of this archive into the root of the SD card.
Power off your SVS, install the SD card and power your SVS back on. That's it!

Remember to mount your IR blaster somewhere near the RT5X so it can detect the IR signals from the SVS.