************************************************************************************************************************
******************************************** SVS Firmware Update Tool V1.0 *********************************************
********************************************      ARTHRIMUS LLC 2024       *********************************************
************************************************************************************************************************

Description
-----------
This is a simple command line tool for updating the firmware of the SVS Control Module. This tool is designed to
automate the firmware update process as much as possible. 

Usage Instructions
------------------

To use the SVS Firmware Update Tool simply launch the batch file labeled "SVS Firmware Update Tool v1.0.bat"

This will launch a command line tool that will automatically scan for your SVS Control Board, and your firmware update 
file, then program the new firmware to your SVS Control Board. You can manually override the automatic COM port and 
firmware file settings from the command window if needed. 

Make sure that when you extracted this archive, the folder structure remains intact as it was inside the archive. The 
command line tool depends on the existing folder structure to work properly.

License Info
------------
This tool is distributed under the MIT License:

Copyright 2024 ARTHRIMUS LLC

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files 
(the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, 
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is 
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR 
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Dependencies
------------
This tool relies on AVRDUDE for programming firmware files over USB.

Avrdude 7.2 is included in this package for your convenience. 

Avrdude is distributed under the GPL V2 license.

The complete text of the license can be found at /tools/avrdude/7.2/LICENSE.txt